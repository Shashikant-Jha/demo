import { Component, OnInit } from '@angular/core';
import { AuthGuardService } from '../../auth-guard.service';
import { Router } from '@angular/router';
import { LoaderService } from '../../common/loader/loader.service';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginAttempt = 0;

  constructor(private auth: AuthGuardService, private router: Router, private loaderService: LoaderService) {
    this.loaderService.show();
   }

  ngOnInit() {
  }

  ngAfterViewInit() {
    this.loaderService.hide();
  }

  login(){
    const point = this;
    point.loginAttempt+=1;
    const username = (<HTMLInputElement>document.getElementById('username')).value;
    const password = (<HTMLInputElement>document.getElementById('password')).value;
    if (username!==null && password!==null && username.length>0 && password.length>0) {
      if (username === 'shashi' && password === 'abracadabra123') {
        point.auth.isLoggedIn = true;
        point.loaderService.show();
        point.router.navigate(['/dashboard']);
      } else {
        if (this.loginAttempt < 3) {
          (<HTMLButtonElement>document.getElementById('modalbutton')).click();
        } else {
          this.router.navigate(['/unauthorized']);
        }
      }
    } else {
      if (this.loginAttempt < 3) {
        (<HTMLButtonElement>document.getElementById('modalbutton')).click();
      } else {
        this.router.navigate(['/unauthorized']);
      }
    }
  }

  cancel() {
    window.location.assign('http://www.google.com');
  }
}
