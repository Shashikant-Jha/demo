export class AppSettings {
    public static chatbotEndpointURL = 'https://api.dialogflow.com/v1/query?v=20150910';
    public static serviceWorkerSupport;
    public static notificationPermission;
 }
