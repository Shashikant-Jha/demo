import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ChatbotTestingComponent } from './chatbot-testing.component';

describe('ChatbotTestingComponent', () => {
  let component: ChatbotTestingComponent;
  let fixture: ComponentFixture<ChatbotTestingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ChatbotTestingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChatbotTestingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
