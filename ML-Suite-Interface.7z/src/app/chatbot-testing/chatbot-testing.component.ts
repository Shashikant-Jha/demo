import { Component, OnInit, AfterViewInit } from '@angular/core';
import { Angular2Csv } from 'angular2-csv/Angular2-csv';
import {ChatbotService} from '../common/services/chatbot.service';
import { FileReaderService } from '../common/services/file-reader.service';
import { AppSettings } from '../core/constants';
import { LoaderService } from '../common/loader/loader.service';
import { v4 as uuid } from 'uuid';

@Component({
  selector: 'app-chatbot-testing',
  templateUrl: './chatbot-testing.component.html',
  styleUrls: ['./chatbot-testing.component.css']
})
export class ChatbotTestingComponent implements OnInit, AfterViewInit {

  view = false;
  toggleButton = true;
  testSet = {};
  accessToken: string;
  errorOccured = false;
  resultVal: Array<any> = [];
  counter = 0;
  tableView = false;
  queryRes: any;
  reqTime: any;
  resTime: any;
  notificationAllowed = false;
  serviceWorkerSupport = false;
  testResult = {
    'totalTests': 0,
    'passedTests': 0,
    'failedTests': 0,
    'accuracyPercentage': 0.0
  };
  sessionID: any;

  constructor(private _file: FileReaderService, private _chat: ChatbotService, private loader: LoaderService) {
    if (AppSettings.notificationPermission && AppSettings.serviceWorkerSupport) {
      this.notificationAllowed = AppSettings.notificationPermission;
      this.serviceWorkerSupport = AppSettings.serviceWorkerSupport;
    }
   }

  ngOnInit() {
    this.sessionID =  uuid();
   }

  ngAfterViewInit() {
    (<HTMLButtonElement>document.getElementById('inputModalButton')).click();
  }

  toggle() {
    this.view = this.toggleButton;
    this.toggleButton = !this.view;
  }

  async startTesting() {
    const point = this;
    point.resultVal = [];
    point. testResult = {
      'totalTests': 0,
      'passedTests': 0,
      'failedTests': 0,
      'accuracyPercentage': 0.0
    };
    console.log(this.testSet);
    console.log(Object.keys(point.testSet).length);
    // tslint:disable-next-line:forin
   if (this.accessToken === null || this.accessToken === undefined) {
    (<HTMLButtonElement>document.getElementById('inputModalButton')).click();
    return;
   }
   if (point.testSet === null || point.testSet === undefined || Object.keys(point.testSet).length === 0) {
    (<HTMLHeadingElement>document.getElementById('errorModalTitle')).innerHTML = 'Warning';
    (<HTMLHeadingElement>document.getElementById('errorModalBody')).innerHTML = 'No File Chosen';
    (<HTMLButtonElement>document.getElementById('errorModalButton')).click();
    return;
   }
   if (point.notificationAllowed && point.serviceWorkerSupport) {
    const notification = navigator.serviceWorker.ready.then(function(registration) {
        registration.showNotification('Chatbot Testing Tool',
        {body: 'Chatbot testing started.', icon: '../../assets/chatIcon.png', dir: 'auto'});
      });
  }
    if (point.testSet !== null && Object.keys(point.testSet).length >= 1) {
      point.tableView = true;
      // tslint:disable-next-line:forin
      for (const key in point.testSet) {
        point.loader.show();
        if (this.testSet.hasOwnProperty(key)) {
          point.reqTime = new Date().toTimeString();
          await point._chat.startTesting(key, this.accessToken, point.sessionID).toPromise()
            .then(res => {
              point.queryRes = res;
              point.resTime = new Date().toTimeString();
               this.validateResults(point.queryRes, point.testSet[key], key);
            })
            .catch(err => {
              console.log(err);
              (<HTMLHeadingElement>document.getElementById('errorModalTitle')).innerHTML = 'Error';
              (<HTMLHeadingElement>document.getElementById('errorModalBody')).innerHTML = err;
              (<HTMLButtonElement>document.getElementById('errorModalButton')).click();
              point.errorOccured = true;
            });
        }
        if (this.errorOccured) {
          point.loader.hide();
          break;
        }
        point.loader.hide();
      }
    }
    if (point.notificationAllowed && point.serviceWorkerSupport) {
      const notification = navigator.serviceWorker.ready.then(function(registration) {
          registration.showNotification('Chatbot Testing Tool',
          {body: 'Chatbot testing completed.', icon: '../../assets/chatIcon.png', dir: 'auto'});
        });
    }
  }

  validateResults(res, eR, query) {
    const point = this;
    this.counter = 0;
    this.testResult.totalTests = this.testResult.totalTests + 1;
    const entities = res.result.parameters;
   if (res.result.fulfillment.messages[1]) {
     if (res.result.fulfillment.messages[1].type === 0) {
      if (res.result.fulfillment.messages[1].speech === eR) {
        const jsonRes = {
          'queryText': query,
          'expectedResult': eR,
          'actualResult': res.result.fulfillment.messages[1].speech,
          'resultValue': 'success',
          'intent': res.result.metadata.intentName,
          'entities': JSON.stringify(entities),
          'contexts': res.result.contexts,
          'reqTime': point.reqTime,
          'resTime': point.resTime
        };
        this.resultVal.push(jsonRes);
        this.testResult.passedTests = this.testResult.passedTests + 1;
      } else {
        const jsonRes = {
          'queryText': query,
          'expectedResult': eR,
          'actualResult': res.result.fulfillment.messages[1].speech,
          'resultValue': 'failure',
          'intent': res.result.metadata.intentName,
          'entities': JSON.stringify(entities),
          'contexts': res.result.contexts,
          'reqTime': point.reqTime,
          'resTime': point.resTime
        };
        this.resultVal.push(jsonRes);
        this.testResult.failedTests = this.testResult.failedTests + 1;
      }
     }
   } else {
    if (res.result.fulfillment.messages[0].type === 0) {
      if (res.result.fulfillment.messages[0].speech === eR) {
        const jsonRes = {
          'queryText': query,
          'expectedResult': eR,
          'actualResult': res.result.fulfillment.messages[0].speech,
          'resultValue': 'success',
          'intent': res.result.metadata.intentName,
          'entities': JSON.stringify(entities),
          'contexts': res.result.contexts,
          'reqTime': point.reqTime,
          'resTime': point.resTime
        };
        this.resultVal.push(jsonRes);
        this.testResult.passedTests = this.testResult.passedTests + 1;
      } else {
        const jsonRes = {
          'queryText': query,
          'expectedResult': eR,
          'actualResult': res.result.fulfillment.messages[0].speech,
          'resultValue': 'failure',
          'intent': res.result.metadata.intentName,
          'entities': JSON.stringify(entities),
          'contexts': res.result.contexts,
          'reqTime': point.reqTime,
          'resTime': point.resTime
        };
        this.resultVal.push(jsonRes);
        this.testResult.failedTests = this.testResult.failedTests + 1;
      }
    }
   }
    this.counter++;
  }

  generateReport(e) {
      e.preventDefault();
      this._file.generateExcel(this.resultVal);
  }

  upload() {
    const point = this;
    point.testSet = this._file.readFile(point.testSet);
  }

  storeToken() {
    this.accessToken = (<HTMLInputElement>document.getElementById('accessToken')).value;
  }
}
