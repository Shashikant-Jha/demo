import { Component, OnInit } from '@angular/core';
import { AnalyticsService } from '../common/services/analytics.service';
import { FileReaderService } from '../common/services/file-reader.service';

@Component({
  selector: 'app-analytics',
  templateUrl: './analytics.component.html',
  styleUrls: ['./analytics.component.css']
})
export class AnalyticsComponent implements OnInit {

  view = false;
  toggleButton = true;
  tableView = false;
  testSet = {};
  index = 1;
  positiveResultSet: Array<any> = [];
  negativeResultSet: Array<any> = [];
  greyResultSet: Array<any> = [];
  constructor(private _analytics: AnalyticsService, private _file: FileReaderService) { }

  ngOnInit() {}

  toggle() {
    this.view = this.toggleButton;
    this.toggleButton = !this.view;
  }

  upload() {
    const point = this;
    point.testSet = this._file.readFile(point.testSet);
  }

  async sentimentAnalysis() {
    const point = this;
    // tslint:disable-next-line:forin
  //  console.log(this.testSet);
    if (point.testSet !== null && Object.keys(point.testSet).length >= 1) {
      for (const key in point.testSet) {
        if (this.testSet.hasOwnProperty(key)) {
          await point._analytics.startTesting(point.testSet[key]).toPromise()
            .then(res => {
              this.calculateScore(res, point.testSet[key]);
            });
        }
      }
    }
    // console.log(this.positiveResultSet);
    // console.log(this.negativeResultSet);
    // console.log(this.greyResultSet);
    this.tableView = true;
  }

  calculateScore(data, key) {
   // console.log(data);
   // console.log(key, ' ', data.documentSentiment.score);
    const json = {
      'feedback': key
    };
    if (data.documentSentiment.score < 0) {
     this.negativeResultSet.push(json) ;
    } else if (data.documentSentiment.score >= 0.4) {
      this.positiveResultSet.push(json);
    } else {
      this.greyResultSet.push(json);
    }
    this._analytics.classifyText(key).subscribe(
      res => console.log(res),
      err => console.log(key, ' ', err)
    );
  }

}
