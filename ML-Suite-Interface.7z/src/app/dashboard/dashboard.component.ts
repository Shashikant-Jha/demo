import { Component, OnInit, HostBinding } from '@angular/core';
import { slideInDownAnimation } from '../animations';
import { LoaderService } from '../common/loader/loader.service';
import { AppSettings } from '../core/constants';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
  animations: [ slideInDownAnimation ]
})
export class DashboardComponent implements OnInit {

  @HostBinding('@routeAnimation') routeAnimation = true;
  @HostBinding('style.display')   display = 'block';
  @HostBinding('style.position')  position = 'absolute';
  view = false;
  toggleButton = true;
  constructor(private loaderService: LoaderService) {
  //  console.log(AppSettings.serviceWorkerSupport);
  }

  ngOnInit() {
  }

  // tslint:disable-next-line:use-life-cycle-interface
  ngAfterViewInit() {
    this.loaderService.hide();
    if (! ('Notification' in window) ) {
    //  console.log('Web Notification not supported');
      return;
  }
    Notification.requestPermission(function(result) {
      if (result === 'granted') {
       AppSettings.notificationPermission = true;
      }
    });
  }

  toggle() {
    this.view = this.toggleButton;
    this.toggleButton = !this.view;
  }

}

