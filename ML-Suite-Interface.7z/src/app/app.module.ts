import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterModule } from '@angular/router';
import { routes } from './app-routing.module';
import { HttpClientModule } from '@angular/common/http';
import { ServiceWorkerModule } from '@angular/service-worker';
import { environment } from '../environments/environment';

import { AppComponent } from './app.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { MenuComponent } from './common/menu/menu.component';
import { ChatbotTestingComponent } from './chatbot-testing/chatbot-testing.component';
import { AnalyticsComponent } from './analytics/analytics.component';

import { AuthGuardService } from './auth-guard.service';
import { LoginComponent } from './core/login/login.component';
import { UnauthorizedComponent } from './core/unauthorized/unauthorized.component';
import { LoaderComponent } from './common/loader/loader.component';
import { LoaderService } from './common/loader/loader.service';

import { FileReaderService } from './common/services/file-reader.service';
import { ChatbotService } from './common/services/chatbot.service';
import { AnalyticsService } from './common/services/analytics.service';

@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent,
    MenuComponent,
    ChatbotTestingComponent,
    AnalyticsComponent,
    LoginComponent,
    UnauthorizedComponent,
    LoaderComponent
  ],
  imports: [
    BrowserModule,
    ServiceWorkerModule.register('/ngsw-worker.js', {
      enabled: environment.production
    }),
    BrowserAnimationsModule,
    HttpClientModule,
    RouterModule.forRoot(routes, {useHash: true})
  ],
  providers: [AuthGuardService, LoaderService, FileReaderService, ChatbotService, AnalyticsService],
  bootstrap: [AppComponent]
})
export class AppModule { }
