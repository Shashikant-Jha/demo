import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent implements OnInit {

  @Input() location: string;
  @Input() view: boolean;
  @Output() sideMenu = new EventEmitter<boolean>();

  constructor() { }

  ngOnInit() {
   // console.log(this.location);
   // console.log(this.view);
  }

toggle() {
  this.view = false;
  this.sideMenu.emit(this.view);
}

}
