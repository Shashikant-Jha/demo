import { Injectable } from '@angular/core';
import { read, IWorkBook } from 'ts-xlsx';
import { Angular2Csv } from 'angular2-csv/Angular2-csv';

@Injectable()
export class FileReaderService {
  constructor() {}

  readFile(testSet): any {
    const point = this;
    const file = (<HTMLInputElement>document.getElementById('fileForUpload'))
      .files[0];
    if (file && file.type === 'text/plain') {
      const reader = new FileReader();
      reader.readAsText(file, 'UTF-8');
      reader.onload = function(evt) {
        testSet = JSON.parse(evt.target['result']);
        return testSet;
      };
      reader.onerror = function(evt) {
       // console.log(evt.error);
      };
    //  console.log(reader.result);
     // console.log(testSet);
    } else if (
      file &&
      file.type ===
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    ) {
      const reader = new FileReader();
      reader.readAsBinaryString(file);
      reader.onloadend = function(evt) {
      const wb: IWorkBook = read(evt.target['result'], { type: 'binary' });
      console.log(wb);
      try {
        const strlen = wb.Sheets.Sheet1['!ref'].split('B');
        for (let i = 1; i <= strlen[1]; i++) {
          const jsonKey = wb.Sheets.Sheet1['A' + i].v;
          const jsonValue = wb.Sheets.Sheet1['B' + i].v;
          testSet[jsonKey] = jsonValue;
        }
      } catch (err) {
        console.log(err);
        point.showModal('Error',
      'Some error occured while reading the file. Check the file and try again');
      }
      };
    } else {
      this.showModal('Invalid File type',
      'The file uploaded is not a text file or an excel file. Please use only a text file or excel file');
    }
    return testSet;
  }

  generateExcel(data) {
    const date = new Date().toDateString();
    const head = ['Query', 'Expected Result', 'Actual Result', 'Result', 'Intent', 'Entities', 'Contexts', 'Request Time', 'Response Time'];
    const title = 'Chatbot testing report';
    const options = {
    showTitle: true,
    showLabels: true,
    headers: head,
    title: title
};
// tslint:disable-next-line:no-unused-expression
new Angular2Csv(data, 'Chatbot report ' + date, options);
  }

  showModal(title, body) {
    (<HTMLHeadingElement>document.getElementById('errorModalTitle')).innerHTML = title;
    (<HTMLDivElement>document.getElementById('errorModalBody')).innerHTML = body;
    (<HTMLButtonElement>document.getElementById('errorModalButton')).click();
  }
}
