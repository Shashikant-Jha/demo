import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpRequest } from '@angular/common/http';

@Injectable()
export class AnalyticsService {

  baseUrl = 'https://language.googleapis.com/v1/documents:analyzeSentiment?key=AIzaSyDlwNlOaVq7ilQC5uqpGnYJGbH-pXSIoes';
  classBaseurl = 'https://language.googleapis.com/v1/documents:annotateText?key=AIzaSyDlwNlOaVq7ilQC5uqpGnYJGbH-pXSIoes'
  constructor(private http: HttpClient) { }

  startTesting(data): any {
    let headers = new HttpHeaders();
    headers = headers.set('Content-Type', 'application/json');
    const body = {
        'document': {
            'type': 'PLAIN_TEXT',
            'language': 'en-US',
            'content': data,
          },
          'encodingType': 'UTF16'
    };
    return  this.http.post(this.baseUrl, JSON.stringify(body), { headers });
  }

  classifyText(data) {
    let headers = new HttpHeaders();
    headers = headers.set('Content-Type', 'application/json');
    const body = {
        'document': {
            'type': 'PLAIN_TEXT',
            'content': data,
          },
          'encodingType': 'UTF16',
          'features': {
            'extractSyntax': true,
            'extractEntities': true,
            'extractDocumentSentiment': true,
            'extractEntitySentiment': true,
            'classifyText': false,
          },
    };
    return  this.http.post(this.classBaseurl, JSON.stringify(body), { headers });
  }

}
