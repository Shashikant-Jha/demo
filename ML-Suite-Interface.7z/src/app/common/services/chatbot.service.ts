import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpRequest } from '@angular/common/http';

@Injectable()
export class ChatbotService {

  baseUrl = 'https://api.dialogflow.com/v1/query?v=20150910';

  constructor(private http: HttpClient) { }

  startTesting(data, accessToken, sessioID): any {
    let headers = new HttpHeaders();
    headers = headers.set('Content-Type', 'application/json');
    headers = headers.set('Authorization', 'Bearer ' + accessToken);
    return  this.http.post(this.baseUrl, JSON.stringify({ query: data, lang: 'en', sessionId: sessioID }), { headers });
  }

}
