import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuardService } from './auth-guard.service';
import { DashboardComponent } from './dashboard/dashboard.component';
import { ChatbotTestingComponent } from './chatbot-testing/chatbot-testing.component';
import { AnalyticsComponent } from './analytics/analytics.component';
import { LoginComponent } from './core/login/login.component';
import { UnauthorizedComponent } from './core/unauthorized/unauthorized.component';

export const routes: Routes = [
    { path: 'dashboard',  canActivate: [AuthGuardService], component: DashboardComponent },
    { path: '', pathMatch: 'full', canActivate: [AuthGuardService], component: DashboardComponent },
    { path: 'analytics', canActivate: [AuthGuardService], component: AnalyticsComponent },
    { path: 'chatbot-testing', canActivate: [AuthGuardService], component: ChatbotTestingComponent },
    { path: 'login', component: LoginComponent },
    { path: 'unauthorized', component: UnauthorizedComponent }
   ];

