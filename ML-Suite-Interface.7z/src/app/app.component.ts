import { Component, AfterViewInit } from '@angular/core';
import { LoaderService } from './common/loader/loader.service';
import { AppSettings } from './core/constants';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements AfterViewInit {

  constructor(private loaderService: LoaderService) {
    this.loaderService.show();
  }

  ngAfterViewInit() {
    this.loaderService.hide();
  if (navigator.serviceWorker) {
    AppSettings.serviceWorkerSupport = true;
  }
    }
}
